
#include <iostream>
#include <fstream>
#include <cmath>	       // Access power function
#include <iomanip>		// Access manipulators
#include"Mortgage.h"
#include"Payments.h"

using namespace std;

float CalcPayment(myMortgage& mortgage1, myPayment& payment1 )
{

    payment1.monthlyInterest = mortgage1.YEARLY_INTEREST / 12;

    payment1.numberOfPayments = mortgage1.NUMBER_OF_YEARS * 12;

    payment1.monthlyPayment =(mortgage1.LOAN_AMOUNT * pow(payment1.monthlyInterest + 1, payment1.numberOfPayments)
                    * payment1.monthlyInterest)/(pow(payment1.monthlyInterest + 1,payment1.numberOfPayments) - 1);

    PrintPaymentInfo(mortgage1,payment1);

    return payment1.monthlyPayment;
}

void PrintPaymentInfo(myMortgage& mortgage1, myPayment& payment1 )
{
// Output results
    cout << fixed << setprecision(2)
         << left << setw(17) << "Loan amount" << right << setw(10) << "$" << mortgage1.LOAN_AMOUNT << endl
         << left << setw(20) << "Interest rate" << right << setw(10) << mortgage1.YEARLY_INTEREST << "%" << endl
         << left << setw(17) << "Mortgage years" << right << setw(10) << mortgage1.NUMBER_OF_YEARS << " years" << endl
         << left << setw(17) << "Monthly payment" << right << setw(10) << "$" << payment1.monthlyPayment << endl<<endl;

}
