#ifndef PAYMENTS_H
#define PAYMENTS_H

void PrintPaymentInfo(myMortgage& , myPayment&);
float CalcPayment(myMortgage&, myPayment&);


#endif
