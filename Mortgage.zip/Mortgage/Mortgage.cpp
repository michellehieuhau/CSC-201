
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>	       // Access power function
#include <iomanip>		// Access manipulators
#include"Mortgage.h"
#include"Payments.h"

using namespace std;

int main()
{
    ifstream inData;
    string filename;

    myMortgage mortgage1;
    myPayment payment1;


	// Ask for file until valid
    do {
        cout << "Enter file name to open: ";
        cin >> filename;

        inData.open(filename.c_str());

        if (!inData)
            cout << "File not found!" << endl;

    } while (!inData);
     //loop to continue get all information in the input file to the end of file

    while (!inData.eof())
    {
        inData>>mortgage1.LOAN_AMOUNT>>mortgage1.YEARLY_INTEREST>>mortgage1.NUMBER_OF_YEARS;

         CalcPayment(mortgage1,payment1 );
    }

    inData.close();
    return 0;
}


/*
//Prompt user for inputs
    cout<<"How much is the amount of loan? ";
    cin>>mortgage1.LOAN_AMOUNT;

    cout<<"What is the interest rate? ";
    cin>>mortgage1.YEARLY_INTEREST;

    cout<<"How many years of the mortgage? ";
    cin>>mortgage1.NUMBER_OF_YEARS;

#include <iostream>
#include <cmath>		// Access power function
#include <iomanip>		// Access manipulators
#include "Mortgage.h"
#include "PaymentInfo.h"

using namespace std;

int main()
{
	MortgageType mortgage;
	PaymentType payment;
	mortgage.loanAmount = 50000.00;
	mortgage.numberOfYears = 7;
	mortgage.yearlyInterest = 0.0524;

	CalcPayment(mortgage, payment);
    return 0;
}
    */
