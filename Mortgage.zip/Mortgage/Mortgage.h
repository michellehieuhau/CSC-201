
#ifndef MORTGAGE_H
#define MORTGAGE_H


struct myMortgage{

    float LOAN_AMOUNT;      // Amount of loan
    float YEARLY_INTEREST;  // Yearly interest
    int NUMBER_OF_YEARS;    // Number of years
};

struct myPayment{
    float monthlyInterest;  // Monthly interest rate
    int numberOfPayments;   // Total number of payments
    float monthlyPayment;          // Monthly payment

};
#endif


