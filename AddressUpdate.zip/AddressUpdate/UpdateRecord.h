#ifndef UPDATERECORD_H
#define UPDATERECORD_H

void DeleteRecord(std::ifstream&, std::string);
void UpdateRecord(std::ifstream&, std::string);

#endif
