#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cctype>
#include "AddressBook.h"
#include "GetRecord.h"
#include "PrintRecord.h"
#include "AddRecord.h"


using namespace std;

/*void DeleteRecord(ifstream& inData, string filename)
{
	vector<string> file;

	string temp;
	string delete_item;

    while (!inData.eof())
    {
        getline(inData,temp);
        file.push_back(temp);
    }
    inData.close();// finish reading file

    cout<<"What information you want to delete: ";
    getline(cin,delete_item);

    for (int i=0; i<(int)file.size();++i)
    {
        if(file[i].substr(0, delete_item.length()) == delete_item)
        {
            file.erase(file.begin() + i);
            cout << "Record to Delete!"<< endl;
            i = 0; // Reset search
        }
    }

    //write new order list back out
    ofstream outData(filename.c_str(), ios::out | ios::trunc);;

    for(vector<string>::const_iterator i = file.begin(); i != file.end(); ++i)
    {
     outData << *i << endl;
    }

	outData.close();

	// Reopen in file stream
	inData.open(filename.c_str());
}*/

 void DeleteRecord(ifstream& inData, string& filename)
{
    entryType record;
	char choice;
	string searchName;
	ofstream outData;

	outData.open("temp.txt");//open temp output file

    do
	{
		cout << "Enter first name of person's record you want to delete: ";
    	getline(cin, searchName);
	} while (!ValidName(searchName));

    normalSearchName = NormalizeString(searchName);     // Convert name to all uppercase

    // Loop through all records in the file
    while (GetRecord(inData, record))
	{
        normalFirstName = NormalizeString(record.name.firstName);   // Convert retrieved string to all uppercase

        if (normalFirstName == normalSearchName) { // Requested name matches
            PrintRecord(record);
            cout << "Is this the correct entry? (Y/N) ";
            cin >> choice;
            cin.ignore(100, '\n');
            choice = toupper(choice);
            cout << endl;

            if (choice == 'Y') {
                found = true;
                break;
            }
        }
    }

    // Matching name was found before the end of the file
    if (inData && found){
        cout << "Record found: " << endl;
        PrintRecord(record);
        cout << "Would you like to delete this record? (Y/N) ";
		cin >> choice;
		cin.ignore(100, '\n');
		choice = toupper(choice);
		cout << endl;
        if (choice=='Y')
        {
            while (getline(inData,line))
            {
                outData<<line;
            }

        }

    }
    else if (!found)   // End of file. Name not found.
    {
        cout << searchName << " not found!" << endl << endl;
    }

    // Clear file fail state and return to beginning
    inData.clear();
    inData.seekg(0);


}



/*	while (getline(inData, line))
    {

            outData << line << endl;
    }

	//inData.close();//close original input file
	//outData.close(); //close temp output file

	//inData.open("temp.txt"); //open temp INPUT file
	//outData.open(filename.c_str()); //open original OUTPUT file


	cout<<"Enter information you would like to delete."<<endl;
	cout<<"Enter first name: ";
	getline(cin,delete_record.name.firstName);
	cout<<"Enter last name: ";
	getline(cin,delete_record.name.lastName);
	cout<<"Enter street address: ";
	getline(cin, delete_record.address.street);
	cout<< "Enter city: "
	getline(cin, delete_record.address.city);
	cout<< "Enter state: "
	getline(cin, delete_record.address.state);
	cout<< "Enter zip code: "
	getline(cin, delete_record.address.zip);
	cout << "Enter phone number in the form (XXX) XXX-XXXX: ";
    getline(cin, delete_phone);



	inData.open("temp.txt"); //open temp input file
	outData.open(filename.c_str()); //open original output file



        // Clear file fail state and return to beginning
      inData.clear();
      inData.seekg(0);
}

    string line;
    // open input file
    ifstream in("infile.txt");
    if( !in.is_open())
    {
          cout << "Input file failed to open\n";
          return 1;
    }
    // now open temp output file
    ofstream out("outfile.txt");
    // loop to read/write the file.  Note that you need to add code here to check
    // if you want to write the line
    while( getline(in,line) )
    {
        if(line != "I want to delete this line")
            out << line << "\n";
    }
    in.close();
    out.close();
    // delete the original file
    remove("infile.txt");
    // rename old to new
    rename("outfile.txt","infile.txt");
    // all done!
    return 0;
}


void DeleteRecord(ifstream& inData, string filename)
{
	ofstream outData;
	entryType record;
	char choice;
	string line;
	string record1, record2, record3;
	string line1, line2, line3;
	char phone1[3], phone2[3], phone3[4];

	outData.open("temp.txt");

	while (getline(inData, line))
		outData << line << endl; //print out all data in original file to tempt

    inData.close();//close original input file
	outData.close(); //close temp output file

	inData.open("temp.txt"); //open temp input file
	outData.open(filename.c_str()); //open original output file

	while (GetRecord(inData, record))
	{
		PrintRecord(record);
		cout << "Would you like to delete this record? (Y/N) ";
		cin >> choice;
		cin.ignore(100, '\n');
		choice = toupper(choice);
		cout << endl;
		if (choice=='Y') break;
	}

	inData.clear();
	inData.seekg(0);

	if (choice=='Y')
	{
		itoa (record.phone.areaCode, phone1, 10);
		itoa (record.phone.prefix, phone2, 10);
		itoa(record.phone.number, phone3, 10);

		record1 = record.name.firstName + ", " + record.name.lastName + ", (" +
				  phone1 + ") " + phone2 + "-" + phone3;
		record2 = record.address.street + ", " + record.address.city + ", " +
				  record.address.state + ", " + record.address.zip;
		record3 = record.media.email + ", " + record.media.facebook + ", " + record.media.twitter;

		while (getline(inData, line1))//get data from temp.txt
		{
			getline(inData, line2);
			getline(inData, line3);

			if (line1==record1 && line2==record2 && line3==record3)
				continue;
			outData << line1 << endl << line2 << endl << line3 << endl;
		}
	}
	else
	{
		while (getline(inData, line))
			outData << line << endl;
	}

	inData.close();
	outData.close();

	inData.open(filename.c_str());
}
*/
