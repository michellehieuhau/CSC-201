#ifndef DELETERECORD_H
#define DELETERECORD_H

void DeleteRecord(std::ifstream&, std::string);


#endif

