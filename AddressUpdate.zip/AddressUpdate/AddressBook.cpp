#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include "AddressBook.h"
#include "GetRecord.h"
#include "PrintRecord.h"
#include "SearchRecord.h"
#include "AddRecord.h"
#include "ValidRecord.h"
#include "UpdateRecord.h"

using namespace std;

void OpenFile(string&, ifstream&);
void MainMenu(ifstream&, string);
void SearchMenu(ifstream&);
void EditMenu(ifstream&, string);

int main()
{
	ifstream fin;
	string fname;

	OpenFile(fname, fin);

	MainMenu(fin, fname);

	return 0;
}

//-------------------------------------------------------------------------------------
// MENU AND BASICS
//-------------------------------------------------------------------------------------

void OpenFile(string& filename, ifstream& inData)
{
    do {
        cout << "Enter file name to open: ";
        cin >> filename;

        inData.open(filename.c_str());

        if (!inData)
            cout << "File not found!" << endl;

    } while (!inData);
}

void MainMenu(ifstream& inData, string filename)
{
    char menuOption;

    do {
        cout << endl;
        cout << "Select an option..." << endl;
        cout << "(E)dit, (P)rint, (S)earch, e(X)it: ";
        cin >> menuOption;
        cin.ignore(100, '\n');
        menuOption = toupper(menuOption);

        switch (menuOption)
		{
            case 'E':
                EditMenu(inData, filename);
                break;
            case 'P':
                PrintAddressBook(inData);
                break;
            case 'S':
                SearchMenu(inData);
                break;
            case 'X':
                break;
            default:
                cout << "Invalid option selected!" << endl;
                break;
        }

        // Clear file fail state and return to beginning
        inData.clear();
        inData.seekg(0);

    } while (menuOption != 'X');
}

void SearchMenu(ifstream& inData)
{
	char searchOption;

	do
	{
        cout << endl;
        cout << "Enter how you want to search... " << endl;
        cout << "(F)irst name, (L)ast name, (A)ddress, (P)hone, (S)ocial Media, e(X)it: ";
        cin >> searchOption;
        cin.ignore(100, '\n');
        searchOption = toupper(searchOption);

		switch(searchOption)
		{
            case 'F':
                SearchFirstName(inData);
                break;
            case 'L':
                SearchLastName(inData);
                break;
            case 'A':
                SearchAddress(inData);
                break;
            case 'P':
                SearchPhone(inData);
                break;
            case 'S':
                SearchSocialMedia(inData);
                break;
            case 'X':
                break;
            default:
                cout << "Invalid option selected!" << endl;
                break;
		}
	} while (searchOption!='X');
}

void EditMenu(ifstream& inData, string filename)
{
	char searchOption;

	do
	{
        cout << endl;
        cout << "Enter how you want to edit... " << endl;
        cout << "(A)dd entry, (U)pdate entry, (D)elete entry, e(X)it: ";
        cin >> searchOption;
        cin.ignore(100, '\n');
        searchOption = toupper(searchOption);

		switch(searchOption)
		{
            case 'A':
                AddEntry(inData, filename);
                break;
            case 'U':
                UpdateRecord(inData, filename);
                break;
            case 'D':
                DeleteRecord(inData, filename);
                break;
            case 'X':
            	break;
            default:
                cout << "Invalid option selected!" << endl;
                break;
		}
	} while (searchOption!='X');
}

