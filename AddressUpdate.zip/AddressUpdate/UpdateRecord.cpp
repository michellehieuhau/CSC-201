#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cctype>
#include "AddressBook.h"
#include "GetRecord.h"
#include "PrintRecord.h"
#include "AddRecord.h"
#include "ValidRecord.h"

using namespace std;
/*
void DeleteRecord(ifstream& inData, string filename)
{
    entryType record;
	char choice;
	string line;
	string searchName;
	ofstream outData;

    string normalSearchName, normalFirstName;
    bool found = false;
	outData.open("temp.txt");//open temp output file


    do
	{
		cout << "Enter first name of person's record you want to delete: ";
    	getline(cin, searchName);
	} while (!ValidName(searchName));

    normalSearchName = NormalizeString(searchName);     // Convert name to all uppercase

    // Loop through all records in the file
    while (GetRecord(inData, record))
	{
        normalFirstName = NormalizeString(record.name.firstName);   // Convert retrieved string to all uppercase

        if (normalFirstName == normalSearchName) { // Requested name matches
            PrintRecord(record);
            cout << "Is this the correct entry? (Y/N) ";
            cin >> choice;
            cin.ignore(100, '\n');
            choice = toupper(choice);
            cout << endl;

            if (choice == 'Y') {
                found = true;
                break;
            }
        }
    }

    // Matching name was found before the end of the file
    if (inData && found){
        cout << "Record found: " << endl;
        PrintRecord(record);
        cout << "Would you like to delete this record? (Y/N) ";
		cin >> choice;
		cin.ignore(100, '\n');
		choice = toupper(choice);
		cout << endl;
        if (choice=='Y')
        {
            while (getline(inData,line))
            {
                outData<<line<<endl;
            }

        }
        cout<<"Record delete!"<<endl;
    }
    else if (!found)   // End of file. Name not found.
    {
        cout << searchName << " not found!" << endl << endl;
    }

    // Clear file fail state and return to beginning
    inData.clear();
    inData.seekg(0);
    inData.close();
	outData.close();


   // delete the original file
    remove(filename.c_str());
    //rename old to new
    rename("temp.txt",filename.c_str());

    inData.open(filename.c_str());

}
*/

void DeleteRecord(ifstream& inData, string filename)
{
    entryType record;
	char choice;
	string line;
	string searchName;
	ofstream outData;

    string normalSearchName, normalFirstName;

    bool found = false;
	outData.open("RecyleBin.txt");//open temp output file
    while (getline(inData, line))
		outData << line << endl; //print out all data in original file to tempt

    inData.close();
	outData.close();

    inData.open("RecyleBin.txt"); //open temp input file
	outData.open(filename.c_str()); //open original output file
    do
	{
		cout << "Enter first name of person's record you want to delete: ";
    	getline(cin, searchName);
	} while (!ValidName(searchName));

    normalSearchName = NormalizeString(searchName);     // Convert name to all uppercase

    // Loop through all records in the file
    while (GetRecord(inData, record))
	{
        normalFirstName = NormalizeString(record.name.firstName);   // Convert retrieved string to all uppercase

        if (normalFirstName == normalSearchName) { // Requested name matches
            PrintRecord(record);
            cout << "Is this the correct entry? (Y/N) ";
            cin >> choice;
            cin.ignore(100, '\n');
            choice = toupper(choice);
            cout << endl;

            if (choice == 'Y') {
                found = true;
                break;
            }
        }
    }

    // Matching name was found before the end of the file
    if (inData && found){
        cout << "Record found: " << endl;
        PrintRecord(record);
        cout << "Would you like to delete this record? (Y/N) ";
		cin >> choice;
		cin.ignore(100, '\n');
		choice = toupper(choice);
		cout << endl;
        if (choice=='Y')
        {

            while (getline(inData,line))
            {
                outData<<line<<endl;
            }

        }
        cout<<"Record delete!"<<endl;
    }
    else if (!found)   // End of file. Name not found.
    {
        cout << searchName << " not found!" << endl << endl;
    }

    // Clear file fail state and return to beginning
    inData.clear();
    inData.seekg(0);

    	inData.open(filename.c_str());

}


 void UpdateRecord(ifstream& inData, string filename)
 {
    entryType record;
	char choice;
	string line,remove_string,update_string;
	string searchName;
	ofstream outData;

    string normalSearchName, normalFirstName;
    bool found = false;
	outData.open("temp.txt");//open temp output file

    do
	{
		cout << "Enter first name of person's record you want to update: ";
    	getline(cin, searchName);
	} while (!ValidName(searchName));

    normalSearchName = NormalizeString(searchName);     // Convert name to all uppercase

    // Loop through all records in the file
    while (GetRecord(inData, record))
	{
        normalFirstName = NormalizeString(record.name.firstName);   // Convert retrieved string to all uppercase

        if (normalFirstName == normalSearchName) { // Requested name matches
            PrintRecord(record);
            cout << "Is this the correct entry? (Y/N) ";
            cin >> choice;
            cin.ignore(100, '\n');
            choice = toupper(choice);
            cout << endl;

            if (choice == 'Y') {
                found = true;
                break;
            }
        }
    }

    // Matching name was found before the end of the file
    if (inData && found){
        cout << "Record found: " << endl;
        PrintRecord(record);
        cout << "Would you like to update this record? (Y/N) ";
		cin >> choice;
		cin.ignore(100, '\n');
		choice = toupper(choice);
		cout << endl;
        if (choice=='Y')
        {
            cout<<"Enter information you want to replace: ";
            getline(cin,remove_string);
            cout<<"Enter new information you want to replace: ";
            getline(cin,update_string);
            while (!inData.eof())
            {
                getline(inData, line);
                if (line==remove_string)
                    outData<<update_string<<endl;
                else
                    outData<<line<<endl;
            }

        }
        cout<<"Record updated!"<<endl;
    }
    else if (!found)   // End of file. Name not found.
    {
        cout << searchName << " not found!" << endl << endl;
    }

    // Clear file fail state and return to beginning
    inData.clear();
    inData.seekg(0);
    inData.close();
	outData.close();


   // delete the original file
    remove(filename.c_str());
    //rename old to new
    rename("temp.txt",filename.c_str());

    inData.open(filename.c_str());
 }



 /*
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cctype>
#include "AddressBook.h"
#include "GetRecord.h"
#include "PrintRecord.h"
#include "AddRecord.h"

using namespace std;

void DeleteRecord(ifstream& inData, string filename)
{
	ofstream outData;
	entryType record;
	char choice;
	string line;
	string record1, record2, record3;
	string line1, line2, line3;
	char phone1[3], phone2[3], phone3[4];

	outData.open("temp.txt");

	while (getline(inData, line))
		outData << line << endl;

	inData.close();
	outData.close();

	inData.open("temp.txt");
	outData.open(filename.c_str());

	while (GetRecord(inData, record))
	{
		PrintRecord(record);
		cout << "Would you like to delete this record? (Y/N) ";
		cin >> choice;
		cin.ignore(100, '\n');
		choice = toupper(choice);
		cout << endl;
		if (choice=='Y') break;
	}

	inData.clear();
	inData.seekg(0);

	if (choice=='Y')
	{
		itoa(record.phone.areaCode, phone1, 10);
		itoa(record.phone.prefix, phone2, 10);
		itoa(record.phone.number, phone3, 10);

		record1 = record.name.firstName + ", " + record.name.lastName + ", (" +
				  phone1 + ") " + phone2 + "-" + phone3;
		record2 = record.address.street + ", " + record.address.city + ", " +
				  record.address.state + ", " + record.address.zip;
		record3 = record.media.email + ", " + record.media.facebook + ", " + record.media.twitter;

		while (getline(inData, line1))
		{
			getline(inData, line2);
			getline(inData, line3);

			if (line1==record1 && line2==record2 && line3==record3)
				continue;
			outData << line1 << endl << line2 << endl << line3 << endl;
		}
	}
	else
	{
		while (getline(inData, line))
			outData << line << endl;
	}

	inData.close();
	outData.close();

	inData.open(filename.c_str());
}

void UpdateRecord(ifstream& inData, string filename)
{
	ofstream outData;
	entryType record, newRecord;
	char choice;
	string line;
	string record1, record2, record3;
	string newRecord1, newRecord2, newRecord3;
	string line1, line2, line3;
	char phone1[3], phone2[3], phone3[4];

	outData.open("temp.txt");

	while (getline(inData, line))
		outData << line << endl;

	inData.close();
	outData.close();

	inData.open("temp.txt");
	outData.open(filename.c_str());

	while (GetRecord(inData, record))
	{
		PrintRecord(record);
		cout << "Would you like to update this record? (Y/N) ";
		cin >> choice;
		cin.ignore(100, '\n');
		choice = toupper(choice);
		cout << endl;
		if (choice=='Y') break;
	}

	inData.clear();
	inData.seekg(0);

	if (choice=='Y')
	{
		itoa(record.phone.areaCode, phone1, 10);
		itoa(record.phone.prefix, phone2, 10);
		itoa(record.phone.number, phone3, 10);

		record1 = record.name.firstName + ", " + record.name.lastName + ", (" +
				  phone1 + ") " + phone2 + "-" + phone3;
		record2 = record.address.street + ", " + record.address.city + ", " +
				  record.address.state + ", " + record.address.zip;
		record3 = record.media.email + ", " + record.media.facebook + ", " + record.media.twitter;

		AddRecord(newRecord);

		itoa(newRecord.phone.areaCode, phone1, 10);
		itoa(newRecord.phone.prefix, phone2, 10);
		itoa(newRecord.phone.number, phone3, 10);

		newRecord1 = newRecord.name.firstName + ", " + newRecord.name.lastName + ", (" +
				  phone1 + ") " + phone2 + "-" + phone3;
		newRecord2 = newRecord.address.street + ", " + newRecord.address.city + ", " +
				  newRecord.address.state + ", " + newRecord.address.zip;
		newRecord3 = newRecord.media.email + ", " + newRecord.media.facebook + ", " + newRecord.media.twitter;

		while (getline(inData, line1))
		{
			getline(inData, line2);
			getline(inData, line3);

			if (line1==record1 && line2==record2 && line3==record3)
				outData << newRecord1 << endl << newRecord2 << endl << newRecord3 << endl;
			else
				outData << line1 << endl << line2 << endl << line3 << endl;
		}
	}
	else
	{
		while (getline(inData, line))
			outData << line << endl;
	}

	inData.close();
	outData.close();

	inData.open(filename.c_str());
}

*/
