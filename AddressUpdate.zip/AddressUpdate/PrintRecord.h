#ifndef PRINTRECORD_H
#define PRINTRECORD_H

void PrintAddressBook(std::ifstream&);
void PrintRecord(entryType);
void PrintBriefRecord(entryType);

#endif
