#ifndef SEARCHRECORD_H
#define SEARCHRECORD_H

void SearchFirstName(std::ifstream&);
void SearchLastName(std::ifstream&);
void SearchAddress(std::ifstream&);
void SearchPhone(std::ifstream&);
void SearchSocialMedia(std::ifstream&);

#endif
